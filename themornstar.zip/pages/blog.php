<section style="width:100%;background:#e3e3f3;margin-top: -14px;background-image: linear-gradient(to bottom, #09090a, #002e47, #00596d, #008460, #26a90f);">

<div class="container">
  <article class="slide-text-article" style="margin-top: 80px;z-index:1;"> 
                           <div class="slide-text-article-heading">
                              BLOG COMING SOON!
                           </div>
                           <div class="slide-text-article-subheading"> This blog section will be available soon . </div>
                           <div style="padding:10px 20px 10px 20px;font-family:ForoSans-ExtraLight;sans-sarif;">
                              <a href="#" class="btn_hairline">Let's Get Started!</a>
                           </div>
     </article>
</div>
						
</section>