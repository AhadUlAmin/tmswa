<?php require '../database_connection.php'?>
<section style="width:100%;background:#e3e3f3;margin-top: -14px;background-image: linear-gradient(to right top, #26a90f, #009766, #007e8b, #006287, #304663);">

<div class="container">
  <article class="slide-text-article" style="margin-top: 80px;z-index:1;"> 
                           <div class="slide-text-article-heading">
                              CAREER PAGE  COMING SOON!
                           </div>
                           <div class="slide-text-article-subheading"> This  section will be available soon . </div>
                           <div style="padding:10px 20px 10px 20px;font-family:ForoSans-ExtraLight;sans-sarif;">
                              <a href="#" class="btn_hairline">Let's Get Started!</a>
                           </div>
     </article>
</div>




<style>
.simpletable{
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;

}
.simpletable tr td a{
	text-decoration: none;
    color: #337990;
    font-weight: 700;
}

.simpletable th,.simpletable td {
  text-align: center;
  padding: 16px;
}

.simpletable th:first-child, .simpletable td:first-child {
  text-align: left;

}
.simpletable tr:nth-child(even) {
    background: rgba(216, 212, 212, 0.43);
}

.fa-check {
  color: green;
}

.fa-remove {
  color: red;
}
</style>
	
	
		<section style="background:#ffffff;width:100%;margin-top:20px;">
				
		<div class="container">
  <h1 style="text-align:center;font-weight: bold;font-size: 28px;font-family: 'ProximaNova-Regular' ,Open Sans;text-align: center;color:#888;line-height:28px;padding:5px;">WANT TO JOIN OUR TEAM?</h1><br>
			<table class="simpletable">
			  <tr>
				<th style="width:50%">Current openings</th>
				<th>Location</th>
				<th>Job Type</th>
			  </tr>
			  <tr>
				<td> <a href="?career_name=PHP-WEB-DEVELOPER&career_type=fulltime&team=ahHMqT&location=Dhaka,Bangladesh">PHP WEB DEVELOPER</a></td>
				<td>Dhaka , Bangladesh </td>
				<td>Fulltime</td>
			  </tr>	

			  <tr>
				<td> <a href="?career_name=DIGITAL-MARKETER">DIGITAL MARKETER</a></td>
				<td>Dhaka , Bangladesh </td>
				<td>Fulltime</td>
			  </tr>		

			  <tr>
				<td> <a href="?career_name=LOGO-AND-GRAPHICS-DESIGNER">LOGO AND GRAPHICS DESIGNER (UX,UI)</a></td>
				<td>Dhaka , Bangladesh </td>
				<td>Fulltime</td>
			  </tr>		

			  <tr>
				<td> <a href="?career_name=PROFESSIONAL-VIDEO-EDITOR"> PROFESSIONAL VIDEO EDITOR </a></td>
				<td>Dhaka , Bangladesh </td>
				<td>Fulltime</td>
			  </tr>
			  
			  <tr>
				<td> <a href="?career_name=SEO_EXPERTS">SEO EXPERTS</a></td>
				<td>Dhaka , Bangladesh </td>
				<td>Fulltime</td>
			  </tr>
			 			  
			  <tr>
				<td> <a href="?career_name=FRONTEND-DEVELOPER">FRONT END DEVELOPER </a></td>
				<td>Dhaka , Bangladesh </td>
				<td>Fulltime</td>
			  </tr>
			 			
			<tr>
				<td> <a href="?career_name=CONSULTANT">CONSULTANT </a></td>
				<td>Dhaka , Bangladesh </td>
				<td>Fulltime</td>
			  </tr>
			 
			</table>
					
					
					
		
		
		
		
		
		

		 
		 
		</div>
		</section>
		
		
	  














						
</section>