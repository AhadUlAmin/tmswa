		<div class="container">
	      <!--- GET IN TOUCH FORM START --->
	


		  <div class="content_simple" style="">
               <h1> Explore Our Services  </h1>
			   <h2 style="text-align:center;"> We provide affordable best custom website & digital marketing  services   </h2>
			   
						<div class="fixxer">
						   <a class="linkadvert" href="services.php?type=php-web-application">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/699595-icon-86-document-file-php-512.png"></div>
								 <div class="advert-title" style=""> PHP Web Application </div>
								 <div class="advert-short-info" style="">We build PHP application from scratch using core php</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=ecommerce-development">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/91-512.png"></div>
								 <div class="advert-title" style="">eCommerce  Development </div>
								 <div class="advert-short-info" style="">We create UX custom multi vendor eCommerce website with payment. </div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=news-portal-developemt">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/178-128.png"></div>
								 <div class="advert-title" style="">News Portal Development  </div>
								 <div class="advert-short-info" style="">We create PHP Ajax Based Speedy User Interface News Portal  </div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=social-api-integration">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/Programming_Development_Api-512.png"></div>
								 <div class="advert-title" style="">Social API Integration </div>
								 <div class="advert-short-info" style="">We integrate Google ,Facebook , Twitter, Instagram , LinkedIn login</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=html5-web-development">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/10-html5-512.png"></div>
								 <div class="advert-title" style="">HTML5 Web Design </div>
								 <div class="advert-short-info" style="">We develop custom website using  HTML5 CSS JavaScript . </div>
							  </div>
						   </a>
						   <br><br>
						   <a class="linkadvert" href="services.php?type=psd-2-html-and-landing-page">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/Web-Design-2-128.png"></div>
								 <div class="advert-title" style="">PSD 2 HTML & Landing Page   </div>
								 <div class="advert-short-info" style="">We build landing page and convert PSD 2 HTML .</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=speedup-and-bugs-fixing">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/performance-clock-speed-512.png"></div>
								 <div class="advert-title" style="">SpeedUp &amp; Bugs Fixing  </div>
								 <div class="advert-short-info" style="">We fix Bugs , Re-Develop Website  , Web Application and Speed Up Website .</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=logo-and-graphics-design">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/Photo%20Shop.png"></div>
								 <div class="advert-title" style="">Logo & Graphics Design </div>
								 <div class="advert-short-info" style="">We create simple meaningful logo and provides Graphics design related to Website.</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=social-ads-and-marketing">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/451_Bullhorn_digital_marketing_media_megaphone_Advertising_Promo_Creative_Process-512.png"></div>
								 <div class="advert-title" style="">Social ADS & Marketing  </div>
								 <div class="advert-short-info" style="">We advertise on Social Media and We do Social Marketing.</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=local-business-video-marketing">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/2-Video_Marketing-512.png"></div>
								 <div class="advert-title" style="">Local Business Video Marketing  </div>
								 <div class="advert-short-info" style="">We rank YouTube Local Business Promotional Video on YouTube and Google First page.</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=searh-engine-optimisation">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/SEO-512.png"></div>
								 <div class="advert-title" style="">Search Engine Optimisation  </div>
								 <div class="advert-short-info" style="">We provide SEO for website at affordable price .</div>
							  </div>
						   </a>
						   <a class="linkadvert" href="services.php?type=content-writing-and-translate">
							  <div class="advert-container" style="">
								 <div class="advert-logo" style="width:100%;float:left;"><img style="" src="https://www.themornstar.com/assets/img/pencil__paper__content__writing__optimization__editing__copywriting-512.png"></div>
								 <div class="advert-title" style="">Content Writing & Translate </div>
								 <div class="advert-short-info" style="">We write quality and specific content for your website and Translate content to English or Any Language . </div>
							  </div>
						   </a>
						</div>
			   
			   


			   
			   
			   
			   
		  </div>
		  
	
	   </div>

           <!--- GET IN TOUCH FORM End --->