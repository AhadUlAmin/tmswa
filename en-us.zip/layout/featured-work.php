
			
<aside class="aside_of_grid_news">

<section class="section_of_grid_news">
	<div class="content_simple" id="loaded_data">
		
		
               <h1>Featured Work </h1>
			   <h2 style="text-align:center;"> Our past adventures</h2>

	</div>
</section>
</aside>