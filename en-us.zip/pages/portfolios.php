<section style="width:100%;background:#e3e3f3;margin-top: -14px;background-image: linear-gradient(to bottom, #3575c0, #7d60b8, #b03f97, #ca1560, #c51e1e);">

<div class="container">
  <article class="slide-text-article" style="margin-top: 80px;z-index:1;"> 
                           <div class="slide-text-article-heading">
                             PORTFOLIOS PAGE  COMING SOON!
                           </div>
                           <div class="slide-text-article-subheading"> This  section will be available soon . </div>
                           <div style="padding:10px 20px 10px 20px;font-family:ForoSans-ExtraLight;sans-sarif;">
                              <a href="#" class="btn_hairline">Let's Get Started!</a>
                           </div>
     </article>
</div>
						
</section>