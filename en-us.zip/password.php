<?php
$str="Aminul";
$str = sha256($str);
    echo "Secure Hash algorithm :<br>".$str;

?>