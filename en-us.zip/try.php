<?php 
echo $_SERVER['REQUEST_URI']."<br>";
echo $_SERVER['SERVER_NAME']."<br>";

?>